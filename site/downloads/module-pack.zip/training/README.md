# Bootcamp content (V1)

This folder will contain the agent-readable bootcamp modules.

Design goals:
- Offline-friendly
- Executable checklists
- Standardized outputs (JSON + Markdown)

