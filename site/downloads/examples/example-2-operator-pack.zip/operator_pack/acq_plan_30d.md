# acq_plan_30d.md
