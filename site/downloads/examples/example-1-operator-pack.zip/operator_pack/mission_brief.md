# mission_brief.md
