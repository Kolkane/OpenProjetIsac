# offer_onepager.md
