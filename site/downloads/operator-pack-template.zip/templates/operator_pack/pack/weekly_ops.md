# weekly_ops.md
